Emoji Sprite
==============


Quick Install
-------------

```
% git clone git://github.com/matsubo/emoji-sprite.git
```

or 

Download from https://github.com/matsubo/emoji-sprite/archive/master.zip


Then, open the `sample/template.html` with web browser.


Directory description
-------------
* data/
  * CSV file to generarte CSS file.
* lib/
  * Core library. copy following directory into your repository.
* sample/
  *  CSS sprite sample HTML.


Usage Detail
-------------

* Please refer to the wiki.
  * https://github.com/matsubo/emoji-sprite/wiki




Author
---------------
Yuki Matsukura


